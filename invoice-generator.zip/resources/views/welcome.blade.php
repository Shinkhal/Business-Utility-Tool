<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Invoice Generator</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net" />
    <link
      href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600"
      rel="stylesheet"
    />

    <!-- Tailwind CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css"
      rel="stylesheet"
    />
  </head>

  <body class="bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 min-h-screen flex flex-col items-center justify-center px-4 lg:px-8">
    <!-- Navbar -->
    <header class="w-full max-w-6xl py-4 flex justify-end">
      @if (Route::has('login'))
      <nav class="space-x-4">
        @auth
        <a
          href="{{ url('/dashboard') }}"
          class="text-sm px-4 py-2 border rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition"
        >
          Dashboard
        </a>
        @else
        <a
          href="{{ route('login') }}"
          class="text-sm px-4 py-2 border rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition"
        >
          Log in
        </a>
        @if (Route::has('register'))
        <a
          href="{{ route('register') }}"
          class="text-sm px-4 py-2 border rounded-md bg-blue-600 text-white hover:bg-blue-700 transition"
        >
          Register
        </a>
        @endif
        @endauth
      </nav>
      @endif
    </header>

    <!-- Main -->
    <main class="w-full max-w-6xl mt-6 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
      <!-- Left Column -->
      <div class="bg-gray-50 dark:bg-gray-800 p-8 rounded-xl shadow-md">
        <h1 class="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-4">Invoice Generator</h1>
        <p class="text-gray-600 dark:text-gray-400 mb-6">
          Quickly create professional invoices with ease.
        </p>

        <div class="mb-8">
          <h2 class="text-xl font-semibold mb-3">Key Features</h2>
          <ul class="space-y-2">
            <li class="flex items-center gap-2">
              <span class="text-green-500">✔</span> Customizable invoices
            </li>
            <li class="flex items-center gap-2">
              <span class="text-green-500">✔</span> Save & track invoices
            </li>
            <li class="flex items-center gap-2">
              <span class="text-green-500">✔</span> Export as PDF
            </li>
            <li class="flex items-center gap-2">
              <span class="text-green-500">✔</span> Client management
            </li>
          </ul>
        </div>

        <div class="flex gap-4">
          <a
            href="{{ route('register') }}"
            class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md transition"
          >
            Get Started
          </a>
          <a
            href="#demo"
            class="border border-gray-300 dark:border-gray-600 hover:border-blue-600 px-5 py-2 rounded-md transition"
          >
            View Demo
          </a>
        </div>
      </div>

      <!-- Right Column -->
      <div class="bg-blue-600 dark:bg-blue-700 text-white p-8 rounded-xl shadow-lg">
        <h2 class="text-2xl font-bold mb-4">Why Choose Us?</h2>
        <ul class="space-y-3 mb-4">
          <li class="flex items-center gap-2">
            <span>🔒</span> Secure & reliable
          </li>
          <li class="flex items-center gap-2">
            <span>⚡</span> Fast & efficient
          </li>
          <li class="flex items-center gap-2">
            <span>📄</span> Professional templates
          </li>
        </ul>
        <p class="text-sm">Join 5,000+ businesses using our tool.</p>
      </div>
    </main>

    <!-- Footer -->
    <footer class="mt-12 text-center text-gray-500 dark:text-gray-400 text-sm">
      &copy; 2025 Invoice Generator. All rights reserved.
    </footer>

    <!-- Dark mode script -->
    <script>
      if (
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches
      ) {
        document.documentElement.classList.add('dark');
      }
    </script>
  </body>
</html>
