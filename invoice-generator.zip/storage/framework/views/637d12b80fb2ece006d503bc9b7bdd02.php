

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dashboard</h1>
    
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">This Month's Revenue</h5>
                    <h2 class="text-success"><?php echo e(number_format($revenueThisMonth, 2)); ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Outstanding Invoices</h5>
                    <h2 class="text-warning"><?php echo e(number_format($outstandingAmount, 2)); ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Overdue Invoices</h5>
                    <h2 class="text-danger"><?php echo e(number_format($overdueAmount, 2)); ?></h2>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Customers</h5>
                    <h2><?php echo e($customerCount); ?></h2>
                    <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Products</h5>
                    <h2><?php echo e($productCount); ?></h2>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Invoices</h5>
                    <h2><?php echo e($invoiceCount); ?></h2>
                    <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-8 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Monthly Revenue</h5>
                    <canvas id="revenueChart" height="250"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">
                    Recent Invoices
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $recentInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <a href="<?php echo e(route('invoices.show', $invoice)); ?>">
                                            #<?php echo e($invoice->invoice_number); ?>

                                        </a>
                                        <div class="small text-secondary"><?php echo e($invoice->customer->name); ?></div>
                                    </div>
                                    <div>
                                        <span class="badge 
                                            <?php echo e($invoice->status === 'paid' ? 'bg-success' : ''); ?>

                                            <?php echo e($invoice->status === 'sent' ? 'bg-warning' : ''); ?>

                                            <?php echo e($invoice->status === 'draft' ? 'bg-secondary' : ''); ?>

                                            <?php echo e($invoice->status === 'cancelled' ? 'bg-danger' : ''); ?>

                                        ">
                                            <?php echo e(ucfirst($invoice->status)); ?>

                                        </span>
                                        <div class="small text-secondary"><?php echo e(number_format($invoice->total, 2)); ?></div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item">No recent invoices</li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-sm btn-outline-primary">View All Invoices</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        
        const monthlyRevenue = [{"month":"Jan","revenue":1200}, ...];
        const labels = monthlyRevenue.map(item => item.month);
        const data = monthlyRevenue.map(item => item.revenue);
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Monthly Revenue',
                    data: data,
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    fill: true
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\invoice-generator\resources\views/dashboard.blade.php ENDPATH**/ ?>