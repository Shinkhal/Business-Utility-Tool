

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Customer Details</h5>
            <div>
                <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-warning btn-sm">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> Back to Customers
                </a>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Basic Information</h6>
                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 35%">Customer Name:</th>
                            <td><?php echo e($customer->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo e($customer->email); ?></td>
                        </tr>
                        <tr>
                            <th>Phone:</th>
                            <td><?php echo e($customer->phone ?? 'Not provided'); ?></td>
                        </tr>
                    </table>
                </div>
                
                <div class="col-md-6">
                    <h6 class="border-bottom pb-2 mb-3">Address Information</h6>
                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 35%">Address:</th>
                            <td><?php echo e($customer->address ?? 'Not provided'); ?></td>
                        </tr>
                        <tr>
                            <th>City:</th>
                            <td><?php echo e($customer->city ?? 'Not provided'); ?></td>
                        </tr>
                        <tr>
                            <th>State/Province:</th>
                            <td><?php echo e($customer->state ?? 'Not provided'); ?></td>
                        </tr>
                        <tr>
                            <th>Postal Code:</th>
                            <td><?php echo e($customer->postal_code ?? 'Not provided'); ?></td>
                        </tr>
                        <tr>
                            <th>Country:</th>
                            <td><?php echo e($customer->country ?? 'Not provided'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12">
                    <h6 class="border-bottom pb-2 mb-3">Customer Invoices</h6>
                    
                    <?php if($invoices->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Invoice #</th>
                                        <th>Date</th>
                                        <th>Due Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($invoice->invoice_number); ?></td>
                                            <td><?php echo e($invoice->invoice_date->format('M d, Y')); ?></td>
                                            <td><?php echo e($invoice->due_date->format('M d, Y')); ?></td>
                                            <td><?php echo e(number_format($invoice->total, 2)); ?></td>
                                            <td>
                                                <?php if($invoice->status == 'paid'): ?>
                                                    <span class="badge bg-success">Paid</span>
                                                <?php elseif($invoice->status == 'sent'): ?>
                                                    <span class="badge bg-info">Sent</span>
                                                <?php elseif($invoice->status == 'draft'): ?>
                                                    <span class="badge bg-secondary">Draft</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Cancelled</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-3">
                            <?php echo e($invoices->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center p-3">
                            <p>No invoices found for this customer.</p>
                            <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Create Invoice
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\invoice-generator\resources\views/customers/show.blade.php ENDPATH**/ ?>