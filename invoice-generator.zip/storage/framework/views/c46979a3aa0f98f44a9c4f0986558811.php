

<?php $__env->startSection('styles'); ?>
<style>
    .delete-row {
        color: #dc3545;
        cursor: pointer;
    }
    .delete-row:hover {
        color: #bd2130;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Create Invoice</h5>
            <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-left"></i> Back to Invoices
            </a>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form action="<?php echo e(route('invoices.store')); ?>" method="POST" id="invoiceForm">
                <?php echo csrf_field(); ?>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title">Customer Information</h6>
                                <div class="mb-3">
                                    <label for="customer_id" class="form-label">Customer <span class="text-danger">*</span></label>
                                    <select class="form-select <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer_id" name="customer_id" required>
                                        <option value="">Select Customer</option>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id') == $customer->id ? 'selected' : ''); ?>>
                                                <?php echo e($customer->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title">Invoice Details</h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="invoice_number" class="form-label">Invoice Number <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="invoice_number" name="invoice_number" value="<?php echo e(old('invoice_number', $invoiceNumber)); ?>" required readonly>
                                        <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" required>
                                            <option value="draft" <?php echo e(old('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                                            <option value="sent" <?php echo e(old('status') == 'sent' ? 'selected' : ''); ?>>Sent</option>
                                            <option value="paid" <?php echo e(old('status') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="invoice_date" class="form-label">Invoice Date <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="invoice_date" name="invoice_date" value="<?php echo e(old('invoice_date', date('Y-m-d'))); ?>" required>
                                        <?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="due_date" class="form-label">Due Date <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="due_date" name="due_date" value="<?php echo e(old('due_date', date('Y-m-d', strtotime('+30 days')))); ?>" required>
                                        <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Invoice Items</h6>
                        <button type="button" class="btn btn-sm btn-primary" id="addItemBtn">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="itemsTable">
                                <thead>
                                    <tr>
                                        <th style="width: 25%">Product</th>
                                        <th style="width: 30%">Description</th>
                                        <th style="width: 10%">Quantity</th>
                                        <th style="width: 15%">Price</th>
                                        <th style="width: 15%">Subtotal</th>
                                        <th style="width: 5%"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(old('items')): ?>
                                        <?php $__currentLoopData = old('items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="item-row">
                                                <td>
                                                    <select class="form-select product-select" name="items[<?php echo e($index); ?>][product_id]">
                                                        <option value="">Select Product</option>
                                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>" data-description="<?php echo e($product->description); ?>" <?php echo e($item['product_id'] == $product->id ? 'selected' : ''); ?>>
                                                                <?php echo e($product->name); ?> (<?php echo e($product->sku); ?>)
                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control item-description" name="items[<?php echo e($index); ?>][description]" required value="<?php echo e($item['description']); ?>">
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control item-quantity" name="items[<?php echo e($index); ?>][quantity]" min="1" required value="<?php echo e($item['quantity']); ?>">
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control item-price" name="items[<?php echo e($index); ?>][price]" step="0.01" min="0" required value="<?php echo e($item['price']); ?>">
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control item-subtotal" name="items[<?php echo e($index); ?>][subtotal]" step="0.01" min="0" required readonly value="<?php echo e($item['subtotal']); ?>">
                                                </td>
                                                <td class="text-center">
                                                    <i class="fas fa-trash delete-row"></i>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr class="item-row">
                                            <td>
                                                <select class="form-select product-select" name="items[0][product_id]">
                                                    <option value="">Select Product</option>
                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>" data-description="<?php echo e($product->description); ?>">
                                                            <?php echo e($product->name); ?> (<?php echo e($product->sku); ?>)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control item-description" name="items[0][description]" required>
                                            </td>
                                            <td>
                                                <input type="number" class="form-control item-quantity" name="items[0][quantity]" min="1" required value="1">
                                            </td>
                                            <td>
                                                <input type="number" class="form-control item-price" name="items[0][price]" step="0.01" min="0" required value="0.00">
                                            </td>
                                            <td>
                                                <input type="number" class="form-control item-subtotal" name="items[0][subtotal]" step="0.01" min="0" required readonly value="0.00">
                                            </td>
                                            <td class="text-center">
                                                <i class="fas fa-trash delete-row"></i>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title">Notes</h6>
                                <div class="mb-3">
                                    <textarea class="form-control" id="notes" name="notes" rows="5"><?php echo e(old('notes')); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title">Summary</h6>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal</span>
                                    <span id="summary-subtotal">0.00</span>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-7">
                                        <div class="input-group">
                                            <input type="number" class="form-control" id="tax_percent" name="tax_percent" step="0.01" min="0" max="100" value="<?php echo e(old('tax_percent', $setting->tax_rate ?? 0)); ?>">
                                            <span class="input-group-text">% Tax</span>
                                        </div>
                                    </div>
                                    <div class="col-5 text-end">
                                        <span id="summary-tax">0.00</span>
                                        <input type="hidden" id="tax_amount" name="tax_amount" value="<?php echo e(old('tax_amount', 0)); ?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-7">
                                        <div class="input-group">
                                            <input type="number" class="form-control" id="discount_percent" name="discount_percent" step="0.01" min="0" max="100" value="<?php echo e(old('discount_percent', 0)); ?>">
                                            <span class="input-group-text">% Discount</span>
                                        </div>
                                    </div>
                                    <div class="col-5 text-end">
                                        <span id="summary-discount">0.00</span>
                                        <input type="hidden" id="discount_amount" name="discount_amount" value="<?php echo e(old('discount_amount', 0)); ?>">
                                    </div>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <h5>Total</h5>
                                    <h5 id="summary-total">0.00</h5>
                                    <input type="hidden" id="subtotal" name="subtotal" value="<?php echo e(old('subtotal', 0)); ?>">
                                    <input type="hidden" id="total" name="total" value="<?php echo e(old('total', 0)); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end">
                    <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary me-2">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Invoice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Item Row Template (Hidden) -->
<table class="d-none">
    <tbody id="item-template">
        <tr class="item-row">
            <td>
                <select class="form-select product-select" name="items[__INDEX__][product_id]">
                    <option value="">Select Product</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>" data-description="<?php echo e($product->description); ?>">
                            <?php echo e($product->name); ?> (<?php echo e($product->sku); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <input type="text" class="form-control item-description" name="items[__INDEX__][description]" required>
            </td>
            <td>
                <input type="number" class="form-control item-quantity" name="items[__INDEX__][quantity]" min="1" required value="1">
            </td>
            <td>
                <input type="number" class="form-control item-price" name="items[__INDEX__][price]" step="0.01" min="0" required value="0.00">
            </td>
            <td>
                <input type="number" class="form-control item-subtotal" name="items[__INDEX__][subtotal]" step="0.01" min="0" required readonly value="0.00">
            </td>
            <td class="text-center">
                <i class="fas fa-trash delete-row"></i>
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        let rowIndex = document.querySelectorAll('.item-row').length;
        
        // Add new item row
        document.getElementById('addItemBtn').addEventListener('click', function() {
            const template = document.getElementById('item-template').innerHTML;
            const newRow = template.replace(/__INDEX__/g, rowIndex);
            
            document.querySelector('#itemsTable tbody').insertAdjacentHTML('beforeend', newRow);
            bindRowEvents(document.querySelectorAll('.item-row')[rowIndex]);
            rowIndex++;
            
            // Update totals
            updateTotals();
        });
        
        // Bind events to existing rows
        document.querySelectorAll('.item-row').forEach(function(row) {
            bindRowEvents(row);
        });
        
        // Handle delete row event
        document.querySelector('#itemsTable tbody').addEventListener('click', function(e) {
            if (e.target.classList.contains('delete-row')) {
                const rows = document.querySelectorAll('.item-row');
                if (rows.length > 1) {
                    e.target.closest('tr').remove();
                    updateTotals();
                } else {
                    alert('Invoice must have at least one item.');
                }
            }
        });
        
        // Handle tax and discount changes
        document.getElementById('tax_percent').addEventListener('input', updateTotals);
        document.getElementById('discount_percent').addEventListener('input', updateTotals);
        
        // Initial calculation
        updateTotals();
        
        // Form validation
        document.getElementById('invoiceForm').addEventListener('submit', function(e) {
            const itemRows = document.querySelectorAll('.item-row');
            if (itemRows.length === 0) {
                e.preventDefault();
                alert('Please add at least one item to the invoice.');
                return false;
            }
            
            // Update all calculations before submit
            updateTotals();
            return true;
        });
        
        // Function to bind events to row elements
        function bindRowEvents(row) {
            // Product selection
            const productSelect = row.querySelector('.product-select');
            productSelect.addEventListener('change', function() {
                const option = this.options[this.selectedIndex];
                if (option.value) {
                    row.querySelector('.item-price').value = option.dataset.price;
                    row.querySelector('.item-description').value = option.dataset.description || '';
                } else {
                    row.querySelector('.item-price').value = '0.00';
                    row.querySelector('.item-description').value = '';
                }
                updateRowTotal(row);
                updateTotals();
            });
            
            // Quantity and price changes
            row.querySelector('.item-quantity').addEventListener('input', function() {
                updateRowTotal(row);
                updateTotals();
            });
            
            row.querySelector('.item-price').addEventListener('input', function() {
                updateRowTotal(row);
                updateTotals();
            });
        }
        
        // Function to update row subtotal
        function updateRowTotal(row) {
            const quantity = parseFloat(row.querySelector('.item-quantity').value) || 0;
            const price = parseFloat(row.querySelector('.item-price').value) || 0;
            const subtotal = quantity * price;
            row.querySelector('.item-subtotal').value = subtotal.toFixed(2);
        }
        
        // Function to update invoice totals
        function updateTotals() {
            let subtotal = 0;
            
            // Sum all line items
            document.querySelectorAll('.item-subtotal').forEach(function(input) {
                subtotal += parseFloat(input.value) || 0;
            });
            
            // Calculate tax and discount
            const taxPercent = parseFloat(document.getElementById('tax_percent').value) || 0;
            const discountPercent = parseFloat(document.getElementById('discount_percent').value) || 0;
            
            const taxAmount = subtotal * (taxPercent / 100);
            const discountAmount = subtotal * (discountPercent / 100);
            
            // Calculate final total
            const total = subtotal + taxAmount - discountAmount;
            
            // Update displays
            document.getElementById('summary-subtotal').textContent = subtotal.toFixed(2);
            document.getElementById('summary-tax').textContent = taxAmount.toFixed(2);
            document.getElementById('summary-discount').textContent = discountAmount.toFixed(2);
            document.getElementById('summary-total').textContent = total.toFixed(2);
            
            // Update hidden fields
            document.getElementById('subtotal').value = subtotal.toFixed(2);
            document.getElementById('tax_amount').value = taxAmount.toFixed(2);
            document.getElementById('discount_amount').value = discountAmount.toFixed(2);
            document.getElementById('total').value = total.toFixed(2);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\invoice-generator\resources\views/invoices/create.blade.php ENDPATH**/ ?>