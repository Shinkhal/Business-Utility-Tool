

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Invoice #<?php echo e($invoice->invoice_number); ?></h5>
            <div>
                <a href="<?php echo e(route('invoices.index')); ?>" class="btn btn-secondary btn-sm me-1">
                    <i class="fas fa-arrow-left"></i> Back to Invoices
                </a>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-cog"></i> Actions
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('invoices.pdf', $invoice)); ?>">
                                <i class="fas fa-download me-2"></i> Download PDF
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('invoices.preview-pdf', $invoice)); ?>" target="_blank">
                                <i class="fas fa-file-pdf me-2"></i> Preview PDF
                            </a>
                        </li>
                        
                        <?php if($invoice->status == 'draft'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('invoices.edit', $invoice)); ?>">
                                    <i class="fas fa-edit me-2"></i> Edit Invoice
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if($invoice->status == 'draft' || $invoice->status == 'sent'): ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('invoices.send', $invoice)); ?>"
                                   onclick="return confirm('Are you sure you want to send this invoice to <?php echo e($invoice->customer->email); ?>?')">
                                    <i class="fas fa-envelope me-2"></i> Send Email
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if($invoice->status == 'sent'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('invoices.paid', $invoice)); ?>"
                                   onclick="return confirm('Mark this invoice as paid?')">
                                    <i class="fas fa-check-circle me-2"></i> Mark as Paid
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if($invoice->status != 'paid' && $invoice->status != 'cancelled'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('invoices.cancel', $invoice)); ?>"
                                   onclick="return confirm('Are you sure you want to cancel this invoice?')">
                                    <i class="fas fa-ban me-2"></i> Cancel Invoice
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if($invoice->status == 'draft' || $invoice->status == 'cancelled'): ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="#" 
                                   onclick="if(confirm('Are you sure you want to delete this invoice?')) { 
                                       document.getElementById('delete-invoice-form').submit(); 
                                   }">
                                    <i class="fas fa-trash me-2"></i> Delete
                                </a>
                                <form id="delete-invoice-form" 
                                      action="<?php echo e(route('invoices.destroy', $invoice)); ?>" 
                                      method="POST" 
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            
            <div class="row mb-4">
                <div class="col-md-7">
                    <div class="d-flex align-items-center mb-4">
                        <div>
                            <h4 class="mb-1"><?php echo e($setting->company_name); ?></h4>
                            <p class="mb-0"><?php echo e($setting->company_address); ?></p>
                            <p class="mb-0"><?php echo e($setting->company_city); ?>, <?php echo e($setting->company_state); ?> <?php echo e($setting->company_postal_code); ?></p>
                            <p class="mb-0"><?php echo e($setting->company_country); ?></p>
                            <p class="mb-0"><?php echo e($setting->company_phone); ?></p>
                            <p class="mb-0"><?php echo e($setting->company_email); ?></p>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h5 class="text-muted mb-2">Bill To:</h5>
                        <h5 class="mb-1"><?php echo e($invoice->customer->name); ?></h5>
                        <p class="mb-0"><?php echo e($invoice->customer->address); ?></p>
                        <p class="mb-0"><?php echo e($invoice->customer->city); ?>, <?php echo e($invoice->customer->state); ?> <?php echo e($invoice->customer->postal_code); ?></p>
                        <p class="mb-0"><?php echo e($invoice->customer->country); ?></p>
                        <p class="mb-0"><?php echo e($invoice->customer->phone); ?></p>
                        <p class="mb-0"><?php echo e($invoice->customer->email); ?></p>
                    </div>
                </div>
                
                <div class="col-md-5">
                    <div class="bg-light p-4 rounded">
                        <div class="row mb-2">
                            <div class="col-6 text-muted">Invoice Number:</div>
                            <div class="col-6 text-end"><?php echo e($invoice->invoice_number); ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6 text-muted">Invoice Date:</div>
                            <div class="col-6 text-end"><?php echo e($invoice->invoice_date->format('M d, Y')); ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6 text-muted">Due Date:</div>
                            <div class="col-6 text-end"><?php echo e($invoice->due_date->format('M d, Y')); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-6 text-muted">Status:</div>
                            <div class="col-6 text-end">
                                <?php if($invoice->status == 'paid'): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php elseif($invoice->status == 'sent'): ?>
                                    <span class="badge bg-info">Sent</span>
                                <?php elseif($invoice->status == 'draft'): ?>
                                    <span class="badge bg-secondary">Draft</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Cancelled</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="table-responsive mb-4">
                <table class="table table-striped border">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 50%">Description</th>
                            <th class="text-center">Quantity</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div><?php echo e($item->description); ?></div>
                                    <?php if($item->product): ?>
                                        <small class="text-muted">SKU: <?php echo e($item->product->sku); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->price, 2)); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->subtotal, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end">Subtotal:</td>
                            <td class="text-end"><?php echo e(number_format($invoice->subtotal, 2)); ?></td>
                        </tr>
                        <?php if($invoice->tax_amount > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end">Tax (<?php echo e($invoice->tax_percent); ?>%):</td>
                                <td class="text-end"><?php echo e(number_format($invoice->tax_amount, 2)); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($invoice->discount_amount > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end">Discount (<?php echo e($invoice->discount_percent); ?>%):</td>
                                <td class="text-end">-<?php echo e(number_format($invoice->discount_amount, 2)); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="3" class="text-end fw-bold">Total:</td>
                            <td class="text-end fw-bold"><?php echo e(number_format($invoice->total, 2)); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <?php if($invoice->notes): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">Notes</h6>
                    </div>
                    <div class="card-body">
                        <?php echo e($invoice->notes); ?>

                    </div>
                </div>
            <?php endif; ?>
            
            <div class="text-center mt-4">
                <p class="mb-0">Thank you for your business!</p>
            </div>
        </div>
        
        <?php if($invoice->status != 'draft' && $invoice->status != 'cancelled'): ?>
            <div class="card-footer">
                <div class="row">
                    <div class="col-md-6">
                        <small class="text-muted">Payment Terms</small>
                        <p class="mb-0"><?php echo e($setting->payment_terms ?? 'Payment due within 30 days.'); ?></p>
                    </div>
                    <div class="col-md-6 text-end">
                        <?php if($setting->bank_details): ?>
                            <small class="text-muted">Bank Information</small>
                            <p class="mb-0"><?php echo e($setting->bank_details); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\invoice-generator\resources\views/invoices/show.blade.php ENDPATH**/ ?>